from .upfirdn2d import upfirdn2d

__all__ = ['upfirdn2d']
